Let's use Skype. If freelancer is sometimes down, I can't contact you. you can download Skype and install. Then after login, you can ping me with my email.

devman80@yandex.com

Thanks.